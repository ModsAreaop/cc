OWNER CONTACT
SITE : https://darkxcode.site
TELEGRAM : t.me/zlaxtert

==================================================================================================
ENGLISH LANGUAGE

IF YOU ARE USING A PROXY LIST PLEASE OPEN FILE 'settings.php' in the function folder

1. install php on your PC or Laptop (there are many ways on Google)
2. set up the PHP environment variable (there are many ways on Google)
3. open file 'open.bat'
4. ENJOY :)

Configuration in file settings.php

mode_proxy = on [to use proxy]
mode_proxy = off [to use proxy]
proxy_list = proxy.txt [name of your proxy file]
proxy_pwd = 'fill in your proxy password' [if your proxy uses a password please fill in otherwise leave blank]
type_proxy = proxy type (example: http , https or socks)
apikey = paste your apikey in file apikey.txt
thisAPI = paste your API in file API.txt
====================================================================================================
