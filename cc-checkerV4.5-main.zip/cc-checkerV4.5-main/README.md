# cc-checkerV4.5
Credit Card Checker Gateway Stripee / Stripe charger $0.5 And Braintree support Check VBV, New Version V4.5 [UPDATE] [29-AUG-2024]

![PHP](https://img.shields.io/badge/language-PHP-blue.svg)
![DARKXCODE](https://img.shields.io/badge/Team-DARKXCODE-black)
![AUTHOR](https://img.shields.io/badge/Author-Zlaxtert-orange)

## Install on desktop : 
- Install XAMPP
- Added environment variable system path => C:\xampp\php
- download the script and save it in your folder
- open CMD and running

## Install on android (Termux)
    $ pkg install git -y
    $ pkg install php -y
    $ git clone https://github.com/ZLaxtert/cc-checkerV4.5
    $ cd cc-checkerV4.5
    $ php cli.php

## Screenshot
<img src="https://github.com/ZLaxtert/cc-checkerV4.5/blob/main/ress.png">


